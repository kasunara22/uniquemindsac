# Photo credits (teaching photos used on the website)
- teach-classroom.jpg — teacher with two young students drawing in a classroom. Source: https://www.veanea.org/wp-content/uploads/2022/11/Special-Education-11_16_22.jpg (page: veanea.org)
- teach-worksheet.jpg — teacher assisting a young boy with a worksheet. Source: https://resources.finalsite.net/images/f_auto,q_auto,t_image_size_4/v1681325622/rsdedu/kz9ix7irt04iq9wg3s8n/ElementarySPED.jpg (page: rsd.edu)
- teach-speech.jpg — speech therapist practising sounds with a young boy. Source: https://parentingpatch.com/wp-content/uploads/2025/01/Speech-therapist-working-with-child-768x512.jpg (page: parentingpatch.com)
- teach-ot.jpg — occupational therapy session. Source: https://sevitahealth.com/wp-content/uploads/2025/02/iStock-1460877748-occupational-feature-1020x600.jpg (page: sevitahealth.com)
- hero-children.jpg, banner.jpg, logo.png, logo-emblem.png — cropped from the academy's own banner image supplied by the owner (2026-11-24).
Note: the four teach-*.jpg photos are third-party web photos; replace them with the academy's own photos when available.
- about-reading.jpg — teacher sharing a picture book with a group of children. Source: https://cid.edu/wp-content/uploads/2023/11/reading-group-1.jpg (page: cid.edu)
