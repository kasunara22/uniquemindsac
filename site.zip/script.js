// Unique Minds Academy — shared site script
(function () {
  // Mobile menu
  var menuBtn = document.getElementById('menuBtn');
  var nav = document.getElementById('navLinks');
  if (menuBtn && nav) {
    menuBtn.addEventListener('click', function () {
      var open = nav.classList.toggle('show');
      menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      menuBtn.textContent = open ? '✕' : '☰';
    });
    nav.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        nav.classList.remove('show');
        menuBtn.setAttribute('aria-expanded', 'false');
        menuBtn.textContent = '☰';
      });
    });
  }

  // FAQ accordion (one open at a time per page)
  document.querySelectorAll('.faq button').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item = btn.parentElement;
      var wasOpen = item.classList.contains('open');
      document.querySelectorAll('.faq.open').forEach(function (f) {
        f.classList.remove('open');
        var b = f.querySelector('button');
        if (b) { b.setAttribute('aria-expanded', 'false'); b.querySelector('span').textContent = '＋'; }
      });
      if (!wasOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
        btn.querySelector('span').textContent = '−';
      }
    });
  });

  // Reveal on scroll
  var revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
      });
    }, { threshold: 0.08 });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in'); });
  }

  // Back to top
  var toTop = document.getElementById('toTop');
  if (toTop) {
    window.addEventListener('scroll', function () {
      toTop.classList.toggle('show', window.scrollY > 500);
    }, { passive: true });
    toTop.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }

  // Footer year
  document.querySelectorAll('[data-year]').forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });

  // Enquiry form (contact page) — front-end only until an email/form service is connected.
  var form = document.getElementById('enquiryForm');
  if (form) {
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var note = document.getElementById('formNote');
      var name = form.elements['name'].value.trim();
      var phone = form.elements['phone'].value.trim();
      var message = form.elements['message'].value.trim();
      if (!name || !phone || !message) {
        note.className = 'form-note error';
        note.textContent = 'Please fill in your name, phone number and message so we can help you.';
        return;
      }
      note.className = 'form-note success';
      note.textContent = 'Thank you, ' + name + '! Your enquiry has been noted on this page. ' +
        'The academy\'s email is still to be added — once it is connected, enquiries will be sent there directly. ' +
        'For anything urgent, please use the contact details shown on this page once they are published.';
      form.reset();
    });
  }
})();

// --- Language toggle EN <-> Sinhala (dictionary of the site's main strings) ---
(function () {
  var SI = {
    "Home":"මුල් පිටුව","About Us":"අප ගැන","Our Programs":"අපගේ වැඩසටහන්","Our Approach":"අපගේ ප්‍රවේශය","FAQs":"නිතර අසන ප්‍රශ්න","Contact":"අප අමතන්න",
    "Talk to Our Team ↗":"අපගේ කණ්ඩායම අමතන්න ↗","Explore Our Programs →":"අපගේ වැඩසටහන් බලන්න →","Discover Our Story":"අපගේ කතාව දැනගන්න",
    "Different ways to learn. One place to shine.":"ඉගෙනීමට විවිධ ක්‍රම. බැබළීමට එකම තැනක්.",
    "At Unique Minds Academy, we celebrate each child's strengths and support their individual learning journey in a caring, encouraging environment.":"Unique Minds Academy හිදී, අපි සෑම දරුවෙකුගේම ශක්තීන් අගය කරන අතර, ආදරණීය සහ දිරිගන්වන පරිසරයක ඔවුන්ගේ තනි ඉගෙනුම් ගමනට සහාය වෙමු.",
    "A welcoming space for every unique mind":"සෑම සුවිශේෂී මනසකටම සාදරයෙන් පිළිගන්නා තැනක්",
    "Child-centred learning":"දරුවා කේන්ද්‍ර කරගත් ඉගෙනුම","Individual growth":"තනි පුද්ගල වර්ධනය","Family partnership":"පවුලේ හවුල්කාරිත්වය","Inclusive environment":"සැමට විවෘත පරිසරය",
    "Special Education":"විශේෂ අධ්‍යාපනය","Speech & Language":"කථන හා භාෂා චිකිත්සාව","Occupational Therapy":"වෘත්තීය චිකිත්සාව","Behaviour & Emotional Support":"හැසිරීම් හා චිත්තවේග සහාය","Life & Skills Development":"ජීවන හා කුසලතා සංවර්ධනය","Early Intervention":"මුල් මැදිහත්වීම",
    "WHAT WE OFFER":"අප ලබාදෙන සේවා","OUR PROMISE":"අපගේ පොරොන්දුව","GETTING STARTED":"ආරම්භ කරන්නේ මෙහෙමයි","GOOD TO KNOW":"දැනගැනීම හොඳයි","LEARNING IN ACTION":"ඉගෙනුම් අවස්ථා",
    "Small steps. Meaningful progress.":"කුඩා පියවර. අර්ථවත් ප්‍රගතිය.","Questions parents often ask":"දෙමාපියන් නිතර අසන ප්‍රශ්න",
    "Let's connect":"අප හා සම්බන්ධ වන්න","Understand the child":"දරුවා තේරුම් ගනිමු","Grow together":"එකට වර්ධනය වෙමු",
    "Care with compassion":"ආදරයෙන් කරන සත්කාරය","Individual attention":"තනි අවධානය","Family partnership":"පවුලේ හවුල්කාරිත්වය","Celebrate progress":"ප්‍රගතිය සමරමු",
    "Contact the Academy ↗":"ඇකඩමිය අමතන්න ↗","Send Enquiry →":"විමසීම යවන්න →","Send an enquiry":"විමසීමක් යවන්න",
    "Parent / caregiver name *":"දෙමාපියාගේ / භාරකරුගේ නම *","Phone number *":"දුරකථන අංකය *","Child's age":"දරුවාගේ වයස","Your message *":"ඔබගේ පණිවිඩය *",
    "Teaching with love, learning with joy":"ආදරයෙන් උගන්වමු, සතුටින් ඉගෙන ගනිමු",
    "Learning together in class":"පන්තියේ එකට ඉගෙන ගනිමු","One-to-one guidance":"තනි පුද්ගල මඟපෙන්වීම","Speech & language practice":"කථන හා භාෂා අභ්‍යාස","Therapy through play":"ක්‍රීඩාවෙන් චිකිත්සාව"
  };
  var btn = document.getElementById('langToggle');
  if (!btn) return;
  var walker, nodes = [];
  function collect() {
    nodes = [];
    var w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode: function (n) {
      if (!n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      var p = n.parentElement; if (!p || p.tagName === 'SCRIPT' || p.tagName === 'STYLE') return NodeFilter.FILTER_REJECT;
      if (p.closest && p.closest('.brand,.footer-brand')) return NodeFilter.FILTER_REJECT; // brand name never translates
      return NodeFilter.FILTER_ACCEPT;
    }});
    var n; while ((n = w.nextNode())) nodes.push(n);
    nodes.forEach(function (n) { if (n.__en === undefined) n.__en = n.nodeValue; });
  }
  function apply(lang) {
    collect();
    nodes.forEach(function (n) {
      if (lang === 'si') {
        var key = n.__en.trim().replace(/\s+/g, ' ');
        if (SI[key]) n.nodeValue = n.__en.replace(key, SI[key]);
      } else { n.nodeValue = n.__en; }
    });
    btn.textContent = lang === 'si' ? 'English' : 'සිංහල';
    document.documentElement.lang = lang === 'si' ? 'si' : 'en';
    try { localStorage.setItem('uma-lang', lang); } catch (e) {}
  }
  var saved = 'en';
  try { saved = localStorage.getItem('uma-lang') || 'en'; } catch (e) {}
  if (saved === 'si') apply('si');
  btn.addEventListener('click', function () {
    apply(document.documentElement.lang === 'si' ? 'en' : 'si');
  });
})();
