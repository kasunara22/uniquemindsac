// Unique Minds Academy — shared site script
(function () {
  // Mobile menu
  var menuBtn = document.getElementById('menuBtn');
  var nav = document.getElementById('navLinks');
  if (menuBtn && nav) {
    menuBtn.addEventListener('click', function () {
      var open = nav.classList.toggle('show');
      menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      menuBtn.textContent = open ? '✕' : '☰';
    });
    nav.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        nav.classList.remove('show');
        menuBtn.setAttribute('aria-expanded', 'false');
        menuBtn.textContent = '☰';
      });
    });
  }

  // FAQ accordion (one open at a time per page)
  document.querySelectorAll('.faq button').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item = btn.parentElement;
      var wasOpen = item.classList.contains('open');
      document.querySelectorAll('.faq.open').forEach(function (f) {
        f.classList.remove('open');
        var b = f.querySelector('button');
        if (b) { b.setAttribute('aria-expanded', 'false'); b.querySelector('span').textContent = '＋'; }
      });
      if (!wasOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
        btn.querySelector('span').textContent = '−';
      }
    });
  });

  // Reveal on scroll
  var revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
      });
    }, { threshold: 0.08 });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in'); });
  }

  // Back to top
  var toTop = document.getElementById('toTop');
  if (toTop) {
    window.addEventListener('scroll', function () {
      toTop.classList.toggle('show', window.scrollY > 500);
    }, { passive: true });
    toTop.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }

  // Footer year
  document.querySelectorAll('[data-year]').forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });

  // Enquiry form (contact page) — front-end only until an email/form service is connected.
  var form = document.getElementById('enquiryForm');
  if (form) {
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var note = document.getElementById('formNote');
      var name = form.elements['name'].value.trim();
      var phone = form.elements['phone'].value.trim();
      var message = form.elements['message'].value.trim();
      if (!name || !phone || !message) {
        note.className = 'form-note error';
        note.textContent = 'Please fill in your name, phone number and message so we can help you.';
        return;
      }
      note.className = 'form-note success';
      note.textContent = 'Thank you, ' + name + '! Your enquiry has been noted on this page. ' +
        'The academy\'s email is still to be added — once it is connected, enquiries will be sent there directly. ' +
        'For anything urgent, please use the contact details shown on this page once they are published.';
      form.reset();
    });
  }
})();

// --- Language toggle EN <-> Sinhala (dictionary of the site's main strings) ---
(function () {
  var SI = {
    "Home":"මුල් පිටුව","About Us":"අප ගැන","Our Programs":"අපගේ වැඩසටහන්","Our Approach":"අපගේ ප්‍රවේශය","FAQs":"නිතර අසන ප්‍රශ්න","Contact":"අප අමතන්න",
    "Talk to Our Team ↗":"අපගේ කණ්ඩායම අමතන්න ↗","Explore Our Programs →":"අපගේ වැඩසටහන් බලන්න →","Discover Our Story":"අපගේ කතාව දැනගන්න",
    "Different ways to learn. One place to shine.":"ඉගෙනීමට විවිධ ක්‍රම. බැබළීමට එකම තැනක්.",
    "At Unique Minds Academy, we celebrate each child's strengths and support their individual learning journey in a caring, encouraging environment.":"Unique Minds Academy හිදී, අපි සෑම දරුවෙකුගේම ශක්තීන් අගය කරන අතර, ආදරණීය සහ දිරිගන්වන පරිසරයක ඔවුන්ගේ තනි ඉගෙනුම් ගමනට සහය වෙමු.",
    "A welcoming space for every unique mind":"සෑම සුවිශේෂී දරුවකුම සාදරයෙන් පිළිගන්නා තැනක්",
    "Child-centred learning":"දරුවා කේන්ද්‍ර කරගත් ඉගෙනුම","Individual growth":"තනි පුද්ගල වර්ධනය","Family partnership":"පවුලේ හවුල්කාරිත්වය","Inclusive environment":"සැමට විවෘත පරිසරය",
    "Special Education":"විශේෂ අධ්‍යාපනය","Speech & Language":"කථන හා භාෂා චිකිත්සාව","Occupational Therapy":"වෘත්තීය චිකිත්සාව","Behaviour & Emotional Support":"හැසිරීම් හා චිත්තවේග සහය","Life & Skills Development":"ජීවන හා කුසලතා සංවර්ධනය","Early Intervention":"මුල් මැදිහත්වීම",
    "WHAT WE OFFER":"අප ලබාදෙන සේවා","OUR PROMISE":"අපගේ පොරොන්දුව","GETTING STARTED":"ආරම්භ කරන්නේ මෙහෙමයි","GOOD TO KNOW":"දැනගැනීම හොඳයි","LEARNING IN ACTION":"ඉගෙනුම් අවස්ථා",
    "Small steps. Meaningful progress.":"කුඩා පියවර. අර්ථවත් ප්‍රගතිය.","Questions parents often ask":"දෙමාපියන් නිතර අසන ප්‍රශ්න",
    "Let's connect":"අප හා සම්බන්ධ වන්න","Understand the child":"දරුවා තේරුම් ගනිමු","Grow together":"එකට වර්ධනය වෙමු",
    "Care with compassion":"ආදරයෙන් කරන සත්කාරය","Individual attention":"තනි අවධානය","Family partnership":"පවුලේ හවුල්කාරිත්වය","Celebrate progress":"ප්‍රගතිය සමරමු",
    "Contact the Academy ↗":"ඇකඩමිය අමතන්න ↗","Send Enquiry →":"විමසීම යවන්න →","Send an enquiry":"විමසීමක් යවන්න",
    "Parent / caregiver name *":"දෙමාපියාගේ / භාරකරුගේ නම *","Phone number *":"දුරකථන අංකය *","Child's age":"දරුවාගේ වයස","Your message *":"ඔබගේ පණිවිඩය *",
    "Teaching with love, learning with joy":"ආදරයෙන් උගන්වමු, සතුටින් ඉගෙන ගනිමු",
    "Learning together in class":"පන්තියේ එකට ඉගෙන ගනිමු","One-to-one guidance":"තනි පුද්ගල මඟපෙන්වීම","Speech & language practice":"කථන හා භාෂා අභ්‍යාස","Therapy through play":"ක්‍රීඩාවෙන් චිකිත්සාව",
    "A little push, a lot of love":"පුංචි තල්ලුවක්, බොහෝ ආදරයක්",
    "That's how every child moves forward.":"සෑම දරුවෙකුම ඉදිරියට යන්නේ එහෙමයි.",
        "Inclusive Learning • Care • Growth":"සැමට විවෘත ඉගෙනුම • සත්කාරය • වර්ධනය",
    "Talk to Our Team":"අපගේ කණ්ඩායම අමතන්න",
    "LET'S TAKE THE FIRST STEP":"පළමු පියවර ගනිමු",
    "Your child's journey is unique.":"ඔබේ දරුවාගේ ගමන සුවිශේෂී එකකි.",
    "Let's support it together.":"අපි එකට එයට සහය වෙමු.",
    "Contact Unique Minds Academy to learn more about our programmes and next steps.":"අපගේ වැඩසටහන් සහ ඊළඟ පියවර ගැන වැඩි විස්තර දැනගැනීමට Unique Minds Academy අමතන්න.",
                "A caring space for learning, development and brighter possibilities.":"ඉගෙනුම, සංවර්ධනය සහ දීප්තිමත් හැකියාවන් සඳහා ආදරණීය තැනක්.",
    "🌈 Every child belongs here":"🌈 සෑම දරුවෙකුටම මෙහි තැනක් ඇත",
    "Explore":"බලන්න",
    "📍 Address: To be added":"📍 ලිපිනය: එකතු කිරීමට ඇත",
    "☎ Phone: To be added":"☎ දුරකථන අංකය: එකතු කිරීමට ඇත",
    "✉ Email: To be added":"✉ විද්‍යුත් තැපෑල: එකතු කිරීමට ඇත",
    "🕘 Hours: To be added":"🕘 වේලාවන්: එකතු කිරීමට ඇත",
    "Unique Minds Academy. All rights reserved.":"Unique Minds Academy. සියලුම හිමිකම් ඇවිරිණි.",
    "✦ ABOUT UNIQUE MINDS ACADEMY":"✦ UNIQUE MINDS ACADEMY ගැන",
    "A caring space for learning, development and brighter possibilities — where each child is understood, encouraged and celebrated.":"ඉගෙනුම, සංවර්ධනය සහ දීප්තිමත් හැකියාවන් සඳහා ආදරණීය තැනක් — සෑම දරුවෙකුම තේරුම් ගෙන, දිරිගන්වා, සමරනු ලබන තැනක්.",
    "Understood • Encouraged • Celebrated":"තේරුම් ගනිමු • දිරිගන්වමු • සමරමු",
    "OUR STORY":"අපගේ කතාව",
    "A place to belong,":"තමන්ගේම යැයි හැඟෙන තැනක්,",
    "learn and flourish.":"ඉගෙන ගෙන දියුණු වෙන්න.",
    "We believe every child deserves to be understood, encouraged and given opportunities to develop. Our goal is to create a supportive learning environment that recognises individual strengths, respects different needs and celebrates every step forward.":"සෑම දරුවෙකුටම තේරුම් ගැනීම, දිරිගැන්වීම සහ වර්ධනය වීමට අවස්ථා ලැබිය යුතු බව අපි විශ්වාස කරමු. තනි ශක්තීන් හඳුනා ගනිමින්, විවිධ අවශ්‍යතාවන්ට ගරු කරමින්, සෑම ඉදිරි පියවරක්ම සමරන, සහය දක්වන ඉගෙනුම් පරිසරයක් නිර්මාණය කිරීම අපගේ අරමුණයි.",
    "At Unique Minds Academy, difference is not a barrier — it is the starting point. We shape learning around the child, not the other way around.":"Unique Minds Academy හිදී, වෙනස්කම බාධාවක් නොවේ — එය ආරම්භක ලක්ෂ්‍යයයි. අපි ඉගෙනුම දරුවා වටා හැඩගස්වමු, අනෙක් අතට නොවේ.",
    "Respect for individuality":"තනිත්වයට ගරු කිරීම",
    "Positive encouragement":"ධනාත්මක දිරිගැන්වීම",
    "Family involvement":"පවුලේ සහභාගීත්වය",
    "Practical life skills":"ප්‍රායෝගික ජීවන කුසලතා",
    "WHAT GUIDES US":"අපව මෙහෙයවන්නේ",
    "Our mission, vision & values":"අපගේ මෙහෙවර, දැක්ම සහ වටිනාකම්",
    "Our Mission":"අපගේ මෙහෙවර",
    "To support each child's individual learning journey with love, understanding and the right guidance — helping every ability grow.":"ආදරය, අවබෝධය සහ නිවැරදි මඟපෙන්වීම සමඟ සෑම දරුවෙකුගේම තනි ඉගෙනුම් ගමනට සහය වීම — සෑම හැකියාවක්ම වර්ධනය වීමට උපකාර කිරීම.",
    "Our Vision":"අපගේ දැක්ම",
    "A world where every child — whatever their way of learning — has one place to shine, and every step forward is celebrated.":"සෑම දරුවෙකුටම — ඔවුන්ගේ ඉගෙනුම් ක්‍රමය කුමක් වුවත් — බැබළීමට එකම තැනක් ඇති, සෑම ඉදිරි පියවරක්ම සමරනු ලබන ලෝකයක්.",
    "Inclusion first":"සැමට විවෘත වීම පළමුව",
    "An inclusive environment where every child belongs, participates and is valued for who they are.":"සෑම දරුවෙකුටම අයිති, සහභාගී වන සහ ඔවුන් කවුද යන්න වෙනුවෙන් අගය කරනු ලබන සැමට විවෘත පරිසරයක්.",
    "A kind, respectful and welcoming environment in everything we do, every day.":"අපි කරන සෑම දෙයකදීම, සෑම දිනකදීම, කරුණාවන්ත, ගෞරවනීය සහ සාදරයෙන් පිළිගන්නා පරිසරයක්.",
    "Parents and caregivers are important partners — involved, informed and heard at every stage.":"දෙමාපියන් සහ භාරකරුවන් වැදගත් හවුල්කරුවන්ය — සෑම අදියරකදීම සම්බන්ධ වී, දැනුවත් වී, ඔවුන්ගේ අදහස්වලට සවන් දෙනු ලැබේ.",
    "Progress, celebrated":"ප්‍රගතිය, සමරමු",
    "Small steps are meaningful progress. Every new skill and achievement matters.":"කුඩා පියවර අර්ථවත් ප්‍රගතියකි. සෑම නව කුසලතාවක්ම සහ ජයග්‍රහණයක්ම වැදගත්ය.",
    "WHO WE WELCOME":"අපි පිළිගන්නේ කවුද",
    "For children who learn":"තමන්ගේම ආකාරයෙන්",
    "in their own way":"ඉගෙන ගන්නා දරුවන් සඳහා",
    "Families of children with different learning and developmental needs — including autism and other developmental or learning needs — are welcome to talk with us. Together, we can discuss whether our support is the right fit for your child.":"විවිධ ඉගෙනුම් සහ සංවර්ධන අවශ්‍යතා ඇති දරුවන්ගේ පවුල් — ඔටිසම් සහ වෙනත් සංවර්ධන හෝ ඉගෙනුම් අවශ්‍යතා ඇතුළුව — අප සමඟ කතා කිරීමට සාදරයෙන් පිළිගනිමු. අපගේ සහය ඔබේ දරුවාට ගැළපේද යන්න අපට එකට සාකච්ඡා කළ හැකිය.",
    "Let's Talk About Your Child →":"ඔබේ දරුවා ගැන කතා කරමු →",
    "✦ OUR APPROACH":"✦ අපගේ ප්‍රවේශය",
    "Small steps.":"කුඩා පියවර.",
    "Meaningful progress.":"අර්ථවත් ප්‍රගතිය.",
    "We focus on the child, work together with families and celebrate progress in all its forms.":"අපි දරුවා කෙරෙහි අවධානය යොමු කරමු, පවුල් සමඟ එකට වැඩ කරමු, ප්‍රගතිය එහි සෑම ආකාරයකින්ම සමරමු.",
    "Four promises to every family":"සෑම පවුලකටම පොරොන්දු හතරක්",
    "A kind, respectful and welcoming environment.":"කරුණාවන්ත, ගෞරවනීය සහ සාදරයෙන් පිළිගන්නා පරිසරයක්.",
    "Learning goals that reflect each child's needs.":"සෑම දරුවෙකුගේම අවශ්‍යතා පිළිබිඹු කරන ඉගෙනුම් ඉලක්ක.",
    "Parents are important partners in every journey.":"සෑම ගමනකදීම දෙමාපියන් වැදගත් හවුල්කරුවන්ය.",
    "Every new skill and achievement matters.":"සෑම නව කුසලතාවක්ම සහ ජයග්‍රහණයක්ම වැදගත්ය.",
    "HOW WE WORK":"අපි වැඩ කරන ආකාරය",
    "Child-centred, in practice":"දරුවා කේන්ද්‍ර කරගත්, ප්‍රායෝගිකව",
    "Our approach starts with the child in front of us — their pace, their ability, their way of learning.":"අපගේ ප්‍රවේශය ආරම්භ වන්නේ අප ඉදිරියේ සිටින දරුවාගෙන් — ඔහුගේ වේගය, ඔහුගේ හැකියාව, ඔහුගේ ඉගෙනුම් ක්‍රමය.",
    "See the strengths first":"පළමුව ශක්තීන් දකිමු",
    "We begin with what each child can do and enjoys, then build learning around those strengths.":"අපි ආරම්භ කරන්නේ සෑම දරුවෙකුටම කළ හැකි සහ කැමති දේවලින් වන අතර, පසුව එම ශක්තීන් වටා ඉගෙනුම ගොඩනඟමු.",
    "Goals that fit the child":"දරුවාට ගැළපෙන ඉලක්ක",
    "Individual learning goals reflect each child's needs, abilities and pace — never a one-size-fits-all plan.":"තනි ඉගෙනුම් ඉලක්ක සෑම දරුවෙකුගේම අවශ්‍යතා, හැකියාවන් සහ වේගය පිළිබිඹු කරයි — කිසිවිටෙක සැමට එකම සැලැස්මක් නොවේ.",
    "Respectful, positive strategies help children build confidence, communication and emotional skills.":"ගෞරවනීය, ධනාත්මක උපාය මාර්ග දරුවන්ට විශ්වාසය, සන්නිවේදනය සහ චිත්තවේග කුසලතා ගොඩනැඟීමට උපකාරී වේ.",
    "Families in the loop":"පවුල් සම්බන්ධ කර ගනිමු",
    "Parents are involved from the first conversation, and progress is reviewed together as the child develops.":"පළමු සංවාදයේ සිටම දෙමාපියන් සම්බන්ධ වන අතර, දරුවා වර්ධනය වන විට ප්‍රගතිය එකට සමාලෝචනය කරනු ලැබේ.",
    "There is no race. Each child progresses in their own time, and every step counts.":"මෙය තරඟයක් නොවේ. සෑම දරුවෙකුම තමන්ගේම කාලය තුළ ප්‍රගතිය ලබන අතර, සෑම පියවරක්ම වැදගත්ය.",
    "Celebrate every step":"සෑම පියවරක්ම සමරමු",
    "New skills — big or small — are noticed, encouraged and celebrated.":"නව කුසලතා — විශාල හෝ කුඩා — නිරීක්ෂණය කර, දිරිගන්වා, සමරනු ලැබේ.",
    "STEP 01":"පියවර 01",
    "STEP 02":"පියවර 02",
    "STEP 03":"පියවර 03",
    "Talk with us about your child, your questions and the support you are looking for.":"ඔබේ දරුවා, ඔබේ ප්‍රශ්න සහ ඔබ සොයන සහය ගැන අප සමඟ කතා කරන්න.",
    "Discuss your child's strengths and needs to explore suitable support and learning goals.":"ගැළපෙන සහය සහ ඉගෙනුම් ඉලක්ක ගවේෂණය කිරීමට ඔබේ දරුවාගේ ශක්තීන් සහ අවශ්‍යතා සාකච්ඡා කරන්න.",
    "Work together with the family and review progress as the child develops.":"පවුල සමඟ එකට වැඩ කරමින්, දරුවා වර්ධනය වන විට ප්‍රගතිය සමාලෝචනය කරන්න.",
    "A supportive journey, step by step":"සහය දක්වන ගමනක්, පියවරෙන් පියවර",
    "We want families to feel informed, welcomed and involved from the very beginning.":"ආරම්භයේ සිටම පවුල්වලට දැනුවත් බව, සාදර පිළිගැනීම සහ සම්බන්ධතාවය දැනේවායි අපි කැමැත්තෙමු.",
    "✦ CONTACT US":"✦ අප අමතන්න",
    "Let's talk about":"අපි කතා කරමු",
    "your child":"ඔබේ දරුවා ගැන",
    "Tell us a little about your child and the support you are looking for. We will guide you through the next steps.":"ඔබේ දරුවා ගැන සහ ඔබ සොයන සහය ගැන අපට ටිකක් කියන්න. ඊළඟ පියවර හරහා අපි ඔබට මඟ පෙන්වන්නෙමු.",
    "Visit us":"අප වෙත එන්න",
    "Address: To be added":"ලිපිනය: එකතු කිරීමට ඇත",
    "Call us":"අපට කතා කරන්න",
    "Phone: To be added":"දුරකථන අංකය: එකතු කිරීමට ඇත",
    "Email us":"අපට විද්‍යුත් තැපෑලක් එවන්න",
    "Email: To be added":"විද්‍යුත් තැපෑල: එකතු කිරීමට ඇත",
    "Opening hours":"විවෘත වේලාවන්",
    "Hours: To be added":"වේලාවන්: එකතු කිරීමට ඇත",
    "What happens next?":"ඊළඟට වෙන්නේ කුමක්ද?",
    "1. We talk about your child and your questions • 2. We discuss strengths, needs and suitable support • 3. We agree the next steps together. No pressure, no obligation.":"1. අපි ඔබේ දරුවා සහ ඔබේ ප්‍රශ්න ගැන කතා කරමු • 2. අපි ශක්තීන්, අවශ්‍යතා සහ ගැළපෙන සහය සාකච්ඡා කරමු • 3. අපි එකට ඊළඟ පියවර එකඟ වෙමු. කිසිදු බලපෑමක් නැත, බැඳීමක් නැත.",
    "Fill this in and we will get back to you. Fields marked * are required.":"මෙය පුරවන්න, අපි ඔබට නැවත සම්බන්ධ වන්නෙමු. * ලකුණු කළ තැන් අනිවාර්ය වේ.",
    "I'm interested in":"මම උනන්දු වන්නේ",
    "Not sure yet — please advise":"තවම විශ්වාස නැත — කරුණාකර උපදෙස් දෙන්න",
    "✦ FAQs":"✦ නිතර අසන ප්‍රශ්න",
    "Questions parents":"දෙමාපියන් නිතර",
    "often ask":"අසන ප්‍රශ්න",
    "We are happy to discuss your child's individual needs with you — here are the answers to the questions we hear most.":"ඔබේ දරුවාගේ තනි අවශ්‍යතා ඔබ සමඟ සාකච්ඡා කිරීමට අපි සතුටු වෙමු — අපට නිතර ඇසෙන ප්‍රශ්නවලට පිළිතුරු මෙන්න.",
    "Which children can enquire about joining?":"ඇතුළත් වීම ගැන විමසිය හැක්කේ කුමන දරුවන්ටද?",
    "Families of children with different learning and developmental needs are welcome to contact us. We can discuss whether our planned support is suitable for your child.":"විවිධ ඉගෙනුම් සහ සංවර්ධන අවශ්‍යතා ඇති දරුවන්ගේ පවුල්වලට අප අමතන්නට සාදරයෙන් පිළිගනිමු. අපගේ සැලසුම් කළ සහය ඔබේ දරුවාට සුදුසුද යන්න අපට සාකච්ඡා කළ හැකිය.",
    "Do you support children with autism?":"ඔබ ඔටිසම් ඇති දරුවන්ට සහය දක්වනවාද?",
    "Our intended services include support for children with autism and other developmental or learning needs. The appropriate programme depends on each child's individual profile.":"අපගේ අපේක්ෂිත සේවාවන්ට ඔටිසම් සහ වෙනත් සංවර්ධන හෝ ඉගෙනුම් අවශ්‍යතා ඇති දරුවන් සඳහා සහය ඇතුළත් වේ. සුදුසු වැඩසටහන සෑම දරුවෙකුගේම තනි පැතිකඩ මත රඳා පවතී.",
    "Can parents meet the team before enrolling?":"ඇතුළත් වීමට පෙර දෙමාපියන්ට කණ්ඩායම හමුවිය හැකිද?",
    "Yes. We encourage parents and caregivers to speak with the team, ask questions and learn about the environment and available programmes before making a decision.":"ඔව්. තීරණයක් ගැනීමට පෙර කණ්ඩායම සමඟ කතා කිරීමට, ප්‍රශ්න ඇසීමට සහ පරිසරය සහ ලබා ගත හැකි වැඩසටහන් ගැන දැන ගැනීමට අපි දෙමාපියන් සහ භාරකරුවන් දිරිගන්වමු.",
    "Are programmes individualised?":"වැඩසටහන් එක් එක් දරුවාට අනුව සකසනවාද?",
    "Yes. Support is shaped around each child's abilities, interests and learning pace, and learning goals reflect the child's individual needs — following an individual assessment and discussion.":"ඔව්. සහය සෑම දරුවෙකුගේම හැකියාවන්, රුචිකත්වයන් සහ ඉගෙනුම් වේගය වටා හැඩගස්වා ඇති අතර, ඉගෙනුම් ඉලක්ක දරුවාගේ තනි අවශ්‍යතා පිළිබිඹු කරයි — තනි ඇගයීමකින් සහ සාකච්ඡාවකින් පසුව.",
    "How do we get started?":"අපි ආරම්භ කරන්නේ කෙසේද?",
    "Start with a conversation. Talk with us about your child and the support you are looking for; then we discuss your child's strengths and needs, explore suitable support and goals, and grow together from there.":"සංවාදයකින් ආරම්භ කරන්න. ඔබේ දරුවා සහ ඔබ සොයන සහය ගැන අප සමඟ කතා කරන්න; පසුව අපි ඔබේ දරුවාගේ ශක්තීන් සහ අවශ්‍යතා සාකච්ඡා කර, ගැළපෙන සහය සහ ඉලක්ක ගවේෂණය කර, එතැන් සිට එකට වර්ධනය වෙමු.",
    "Are therapy services provided by qualified professionals?":"චිකිත්සා සේවා සුදුසුකම් ලත් වෘත්තිකයන් විසින් සපයනු ලබනවාද?",
    "Please contact the academy to confirm which services are currently available and the qualifications of the professionals providing them.":"දැනට ලබා ගත හැකි සේවා සහ ඒවා සපයන වෘත්තිකයන්ගේ සුදුසුකම් තහවුරු කිරීමට කරුණාකර ඇකඩමිය අමතන්න.",
    "Can I ask a question that is not listed here?":"මෙහි නැති ප්‍රශ්නයක් මට ඇසිය හැකිද?",
    "Of course. Every child's journey is unique, and we are happy to discuss your child's individual needs with you. Reach us through the Contact page.":"ඇත්තෙන්ම. සෑම දරුවෙකුගේම ගමන සුවිශේෂී වන අතර, ඔබේ දරුවාගේ තනි අවශ්‍යතා ඔබ සමඟ සාකච්ඡා කිරීමට අපි සතුටු වෙමු. අප අමතන්න පිටුව හරහා අප හා සම්බන්ධ වන්න.",
    "Still unsure about something?":"තවමත් යමක් ගැන විශ්වාස නැද්ද?",
    "Every child is different, and so is every question.":"සෑම දරුවෙකුම වෙනස්ය, සෑම ප්‍රශ්නයක්ම ද එසේමය.",
    "Contact the academy →":"ඇකඩමිය අමතන්න →",
    "and we will talk it through together.":"අපි එකට ඒ ගැන කතා කරමු.",
    "✦ Every child has a bright future":"✦ සෑම දරුවෙකුටම දීප්තිමත් අනාගතයක් ඇත",
    "Different ways":"විවිධ ක්‍රම",
    "to learn.":"ඉගෙනුමෙන් -",
    "One place":"අන් අය මෙන්ම",
    "to shine.":"බැබලෙමු",
    "💛 Every child matters":"💛 සෑම දරුවෙකුම වැදගත්ය",
    "🌱 A little push, a lot of love — that's how every child moves forward.":"🌱 පුංචි තල්ලුවක්, බොහෝ ආදරයක් — සෑම දරුවෙකුම ඉදිරියට යන්නේ එහෙමයි.",
    "✨ You can shine!":"✨ ඔබට බැබළිය හැකිය!",
    "Every ability matters. Every day.":"සෑම හැකියාවක්ම වැදගත්ය. සෑම දිනකම.",
    "WELCOME TO UNIQUE MINDS":"UNIQUE MINDS වෙත සාදරයෙන් පිළිගනිමු",
    "More About Us →":"අප ගැන වැඩි විස්තර →",
    "Support shaped around":"සහය හැඩගස්වා ඇත්තේ",
    "each child's needs":"සෑම දරුවෙකුගේම අවශ්‍යතා වටා",
    "Learning and development support for children with a range of learning and developmental needs — tailored following an individual assessment.":"විවිධ ඉගෙනුම් සහ සංවර්ධන අවශ්‍යතා ඇති දරුවන් සඳහා ඉගෙනුම් සහ සංවර්ධන සහය — තනි ඇගයීමකින් පසුව ගැළපෙන පරිදි සකසා ඇත.",
    "Individualised learning activities designed around each child's abilities, interests and learning pace.":"සෑම දරුවෙකුගේම හැකියාවන්, රුචිකත්වයන් සහ ඉගෙනුම් වේගය වටා සැලසුම් කළ තනි පුද්ගල ඉගෙනුම් ක්‍රියාකාරකම්.",
    "Learn more →":"වැඩි විස්තර →",
    "Support to develop communication, language understanding and ways to express needs and ideas.":"සන්නිවේදනය, භාෂා අවබෝධය සහ අවශ්‍යතා සහ අදහස් ප්‍රකාශ කිරීමේ ක්‍රම වර්ධනය කිරීමට සහය.",
    "Support for everyday activities, sensory needs, coordination and greater independence.":"දෛනික ක්‍රියාකාරකම්, සංවේදී අවශ්‍යතා, සම්බන්ධීකරණය සහ වැඩි ස්වාධීනත්වය සඳහා සහය.",
    "Positive, respectful strategies that help children develop confidence and emotional skills.":"දරුවන්ට විශ්වාසය සහ චිත්තවේග කුසලතා වර්ධනය කිරීමට උපකාරී වන ධනාත්මක, ගෞරවනීය උපාය මාර්ග.",
    "Practical skills for communication, social interaction, self-care and daily living.":"සන්නිවේදනය, සමාජ අන්තර්ක්‍රියා, ස්වයං රැකවරණය සහ දෛනික ජීවිතය සඳහා ප්‍රායෝගික කුසලතා.",
    "Early, family-centred support to help identify strengths and build developmental skills.":"ශක්තීන් හඳුනා ගැනීමට සහ සංවර්ධන කුසලතා ගොඩනැඟීමට උපකාරී වන මුල්, පවුල කේන්ද්‍ර කරගත් සහය.",
    "See Our Approach →":"අපගේ ප්‍රවේශය බලන්න →",
    "Teaching with love,":"ආදරයෙන් උගන්වමින්,",
    "learning with joy":"සතුටින් ඉගෙන ගනිමු",
    "Real moments of one-to-one support — in the classroom, in therapy and through play.":"තනි පුද්ගල සහයේ සැබෑ අවස්ථා — පන්ති කාමරයේ, චිකිත්සාවේ සහ ක්‍රීඩාව හරහා.",
    "🧩 Learning together in class":"🧩 පන්තියේ එකට ඉගෙන ගනිමු",
    "✏️ One-to-one guidance":"✏️ තනි පුද්ගල මඟපෙන්වීම",
    "💬 Speech & language practice":"💬 කථන හා භාෂා අභ්‍යාස",
    "👐 Therapy through play":"👐 ක්‍රීඩාවෙන් චිකිත්සාව",
    "We are happy to discuss your child's individual needs with you.":"ඔබේ දරුවාගේ තනි අවශ්‍යතා ඔබ සමඟ සාකච්ඡා කිරීමට අපි සතුටු වෙමු.",
    "See All FAQs →":"සියලුම නිතර අසන ප්‍රශ්න බලන්න →",
    "✦ OUR PROGRAMS":"✦ අපගේ වැඩසටහන්",
    "Our learning and development areas can support children with a range of learning and developmental needs. Every programme is tailored following an individual assessment.":"අපගේ ඉගෙනුම් සහ සංවර්ධන ක්ෂේත්‍රවලට විවිධ ඉගෙනුම් සහ සංවර්ධන අවශ්‍යතා ඇති දරුවන්ට සහය විය හැකිය. සෑම වැඩසටහනක්ම තනි ඇගයීමකින් පසුව ගැළපෙන පරිදි සකසා ඇත.",
    "Learning activities matched to ability and pace":"හැකියාවට සහ වේගයට ගැළපෙන ඉගෙනුම් ක්‍රියාකාරකම්",
    "Goals built around the child's strengths and interests":"දරුවාගේ ශක්තීන් සහ රුචිකත්වයන් වටා ගොඩනැඟූ ඉලක්ක",
    "Regular review as the child progresses":"දරුවා ප්‍රගතිය ලබන විට නිතිපතා සමාලෝචනය",
    "Understanding and using language":"භාෂාව තේරුම් ගැනීම සහ භාවිතය",
    "Expressing needs, choices and ideas":"අවශ්‍යතා, තේරීම් සහ අදහස් ප්‍රකාශ කිරීම",
    "Building confidence in everyday communication":"දෛනික සන්නිවේදනයේ විශ්වාසය ගොඩනැඟීම",
    "Everyday self-care and daily activities":"දෛනික ස්වයං රැකවරණය සහ දෛනික ක්‍රියාකාරකම්",
    "Sensory needs and coordination":"සංවේදී අවශ්‍යතා සහ සම්බන්ධීකරණය",
    "Steps towards greater independence":"වැඩි ස්වාධීනත්වය කරා පියවර",
    "Positive, respectful behaviour strategies":"ධනාත්මක, ගෞරවනීය හැසිරීම් උපාය මාර්ග",
    "Understanding and expressing emotions":"චිත්තවේග තේරුම් ගැනීම සහ ප්‍රකාශ කිරීම",
    "Confidence and social-emotional skills":"විශ්වාසය සහ සමාජ-චිත්තවේග කුසලතා",
    "Communication in daily life":"දෛනික ජීවිතයේ සන්නිවේදනය",
    "Social interaction with others":"අන් අය සමඟ සමාජ අන්තර්ක්‍රියා",
    "Self-care and daily living skills":"ස්වයං රැකවරණය සහ දෛනික ජීවන කුසලතා",
    "Early identification of strengths":"ශක්තීන් මුල් අවදියේම හඳුනා ගැනීම",
    "Building developmental skills step by step":"සංවර්ධන කුසලතා පියවරෙන් පියවර ගොඩනැඟීම",
    "Family-centred support from the start":"ආරම්භයේ සිටම පවුල කේන්ද්‍ර කරගත් සහය",
    "Not sure which programme fits?":"කුමන වැඩසටහන ගැළපේද යන්න විශ්වාස නැද්ද?",
    "That is completely normal. Talk to us about your child — together we will discuss their strengths and needs and explore the most suitable support and learning goals.":"එය සම්පූර්ණයෙන්ම සාමාන්‍ය දෙයකි. ඔබේ දරුවා ගැන අප සමඟ කතා කරන්න — අපි එකට ඔවුන්ගේ ශක්තීන් සහ අවශ්‍යතා සාකච්ඡා කර, වඩාත් ගැළපෙන සහය සහ ඉගෙනුම් ඉලක්ක ගවේෂණය කරමු.",
    "Talk to our team →":"අපගේ කණ්ඩායම අමතන්න →",
    "HOW PLACEMENT WORKS":"ස්ථානගත කිරීම ක්‍රියාත්මක වන ආකාරය",
    "Tailored, never one-size-fits-all":"ගැළපෙන පරිදි සකසා ඇත, කිසිවිටෙක සැමට එකම ප්‍රමාණය නොවේ",
    "The appropriate programme always depends on each child's individual profile.":"සුදුසු වැඩසටහන සැමවිටම සෑම දරුවෙකුගේම තනි පැතිකඩ මත රඳා පවතී.",
    "Share your child's story, questions and the support you are looking for.":"ඔබේ දරුවාගේ කතාව, ප්‍රශ්න සහ ඔබ සොයන සහය අප සමඟ බෙදා ගන්න.",
    "An individual discussion of strengths and needs shapes suitable goals.":"ශක්තීන් සහ අවශ්‍යතා පිළිබඳ තනි සාකච්ඡාවක් ගැළපෙන ඉලක්ක හැඩගස්වයි.",
    "The programme is reviewed with the family as the child develops.":"දරුවා වර්ධනය වන විට වැඩසටහන පවුල සමඟ සමාලෝචනය කරනු ලැබේ.",
    "Every child receives individual attention — we focus on each child separately, at their own pace.":"සෑම දරුවෙකුටම තනි අවධානය ලැබේ — අපි එක් එක් දරුවා ගැන වෙන වෙනම, දරුවාගේම වේගයට අනුව අවධානය යොමු කරමු."
  };
  var btn = document.getElementById('langToggle');
  if (!btn) return;
  var walker, nodes = [];
  function collect() {
    nodes = [];
    var w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode: function (n) {
      if (!n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      var p = n.parentElement; if (!p || p.tagName === 'SCRIPT' || p.tagName === 'STYLE') return NodeFilter.FILTER_REJECT;
      if (p.closest && p.closest('.brand,.footer-brand')) return NodeFilter.FILTER_REJECT; // brand name never translates
      return NodeFilter.FILTER_ACCEPT;
    }});
    var n; while ((n = w.nextNode())) nodes.push(n);
    nodes.forEach(function (n) { if (n.__en === undefined) n.__en = n.nodeValue; });
  }
  function apply(lang) {
    collect();
    nodes.forEach(function (n) {
      if (lang === 'si') {
        var key = n.__en.trim().replace(/\s+/g, ' ');
        if (SI[key]) { var lead = n.__en.match(/^\s*/)[0], trail = n.__en.match(/\s*$/)[0]; n.nodeValue = lead + SI[key] + trail; }
      } else { n.nodeValue = n.__en; }
    });
    btn.textContent = lang === 'si' ? 'English' : 'සිංහල';
    document.documentElement.lang = lang === 'si' ? 'si' : 'en';
    try { localStorage.setItem('uma-lang', lang); } catch (e) {}
  }
  var saved = 'en';
  try { saved = localStorage.getItem('uma-lang') || 'en'; } catch (e) {}
  if (saved === 'si') apply('si');
  btn.addEventListener('click', function () {
    apply(document.documentElement.lang === 'si' ? 'en' : 'si');
  });
})();
